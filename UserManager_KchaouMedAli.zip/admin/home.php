<!DOCTYPE html>
<html>
<head>
<?php

include('../config.php');

?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>

body {
  margin: 0;
  font-family: "Lato", sans-serif;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #299be4;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 275px;
  background: #fcfcfc;
  padding-top: 50px;
}

.table-wrapper {
    background: rgba(255, 255, 255, 0);
    border-radius: 3px;
    box-shadow: 0 1px 1px rgba(0,0,0,.05);
}
.table-title {
    padding-bottom: 15px;
    background: #299be4;
    color: #fff;
    padding: 16px 30px;
    margin: -20px -25px 10px;
    border-radius: 3px 3px 0 0;
}
.table-title h2 {
    margin: 5px 0 0;
    font-size: 24px;
}
.table-title .btn {
    color: #566787;
    float: right;
    font-size: 13px;
    background: #fff;
    border: none;
    min-width: 50px;
    border-radius: 2px;
    border: none;
    outline: none !important;
    margin-left: 10px;
}
.table-title .btn:hover, .table-title .btn:focus {
    color: #566787;
    background: #f2f2f2;
}
.table-title .btn i {
    float: left;
    font-size: 21px;
    margin-right: 5px;
}
.table-title .btn span {
    float: left;
    margin-top: 2px;
}
table.table tr th, table.table tr td {
    border-color: #e9e9e9;
    padding: 12px;
    vertical-align: middle;
}
table.table tr th:first-child {
    width: 80px;
}
table.table tr th:last-child {
    width: 80px;
}
table.table-striped tbody tr:nth-of-type(odd) {
    background-color: #fcfcfc;
}
table.table-striped.table-hover tbody tr:hover {
    background: #f5f5f5;
}
table.table th i {
    font-size: 13px;
    margin: 0 5px;
    cursor: pointer;
}	
table.table td:last-child i {
    opacity: 0.9;
    font-size: 22px;
    margin: 0 5px;
}
table.table td a {
    font-weight: bold;
    color: #566787;
    display: inline-block;
    text-decoration: none;
}
table.table td a:hover {
    color: #2196F3;
}
table.table td a.settings {
    color: #2196F3;
}
table.table td a.delete {
    color: #F44336;
}
table.table td i {
    font-size: 19px;
}
table.table .avatar {
    border-radius: 50%;
    vertical-align: middle;
    margin-right: 10px;
}
.status {
    font-size: 30px;
    margin: 2px 2px 0 0;
    display: inline-block;
    vertical-align: middle;
    line-height: 10px;
}
.text-success {
    color: #10c469;
}
.text-info {
    color: #62c9e8;
}
.text-warning {
    color: #FFC107;
}
.text-danger {
    color: #ff5b5b;
}
.pagination {
    float: right;
    margin: 0 0 5px;
}
.pagination li a {
    border: none;
    font-size: 13px;
    min-width: 30px;
    min-height: 30px;
    color: #999;
    margin: 0 2px;
    line-height: 30px;
    border-radius: 2px !important;
    text-align: center;
    padding: 0 6px;
}
.pagination li a:hover {
    color: #666;
}	
.pagination li.active a, .pagination li.active a.page-link {
    background: #03A9F4;
}
.pagination li.active a:hover {        
    background: #0397d6;
}
.pagination li.disabled i {
    color: #ccc;
}
.pagination li i {
    font-size: 16px;
    padding-top: 6px
}
.hint-text {
    float: left;
    margin-top: 10px;
    font-size: 13px;
}
input{
	width:50px;
	border: none;
	margin: 0;
	color: rgba(0,0,0,0);
	cursor: pointer;
	border-radius: 15px;
}
</style>
</head>
<body>

<div class="sidebar">
  <a class="active" href="?page=home">Home</a>
  <a href="?page=users">User Manager</a>
</div>
<div class="content">
<!-- Title -->
<?php

if ($_GET['page']=='home' or !$_GET['page']){
	$page = 'Home';
	echo "<h1><center>$page</center></h1>";
	$name = 'med';
	echo "<br><br><h2><center>Welcome Admin</center></h2>";
	
}
?>	
<!-- User Manager -->
<div class="container-xl" id="users" style="display: None; width:85%;">
    <div class="table-responsive">
	<h1><center>User Manager</center></h1><br><br>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-5">
                        <h2>User <b>Management</b></h2>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
              
<?php

$connection = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT id_p, nom_p, pernom_p, adresse_p, date_de_naissance, email_p FROM personnes";

if ($result = $connection -> query($sql)) {
  // Get field information for all fields
  echo "<tr>";
  while ($fieldinfo = $result -> fetch_field()) {
	  $key_name = $fieldinfo -> name;
	  echo "<th>".ucfirst($key_name)."</th>";
  }
  $result -> free_result();
  echo "<th>Role</th>";
		echo "<th>Upgrade</th>";
		echo "<th>Downgrade</th>";
		echo "<th>Delete</th>";
  echo "</tr>";
}

$connection -> close();


?>
                </thead>
                <tbody>
<?php
if (isset($_POST['admin'])){
	$connection = new mysqli($servername, $username, $password, $dbname);
	$id_p = $_POST['admin'];
	$sql = "INSERT INTO administrateur (id_admin) VALUES ('$id_p')";
	if ($connection->query($sql) === TRUE){
		echo "<script>alert('".$id_p.": New Admin Added');</script>";
	}
	else{
		echo "<script>alert('".$id_p.": Already Admin');</script>";
	}
	$connection->close();
}

if (isset($_POST['user'])){
	$connection = new mysqli($servername, $username, $password, $dbname);
	$id_p = $_POST['user'];
	$sql = "DELETE FROM `administrateur` WHERE administrateur.id_admin=".$id_p;
	if ($connection->query($sql) === TRUE){
		echo "<script>alert('".$id_p.": New Admin Downgraded');</script>";
	}
	else{
		echo "<script>alert('".$id_p.": Already User');</script>";
	}
	$connection->close();
}

if (isset($_POST['delete'])){
	$connection = new mysqli($servername, $username, $password, $dbname);
	$id_p = $_POST['delete'];
	$sql = "DELETE FROM `administrateur` WHERE administrateur.id_admin=".$id_p;
	$connection->query($sql);
	$connection->close();
	$connection = new mysqli($servername, $username, $password, $dbname);
	$sql = "DELETE FROM `personnes` WHERE personnes.id_p=".$id_p;
	if ($connection->query($sql) === TRUE){
		echo "<script>alert('".$id_p.": User Deleted');</script>";
	}
	else{
		echo "<script>alert('".$id_p.": User Can not be Deleted');</script>";
	}
	$connection->close();
}
?>
<form method="POST">
<?php

$connection = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT id_p, nom_p, pernom_p, adresse_p, date_de_naissance, email_p, id_admin FROM personnes LEFT JOIN administrateur on administrateur.id_admin=personnes.id_p";

if ($result = $connection -> query($sql)) {
  // Get field information for all fields
  echo "<tr>";
    while ($row = mysqli_fetch_row($result)) {
		echo "<tr>";
		echo "<th>".$row[0]."</th>";
        foreach($row as $key){
			if ($key!=$row[0]){
				echo "<td>".$key."</td>";
			}
		}
		if ($row[6]){
			echo "<th>Admin</th>";
		}
		echo "<th><input type='submit' name='admin' value='".$row[0]."' style='background:#93e095;'></th>";
		echo "<th><input type='submit' name='user' value='".$row[0]."' style='background:#efd764;'></th>";
		echo "<th><input type='submit' name='delete' value='".$row[0]."' style='background:#ff1657;'></th>";
		echo "</tr>";
    }
	
  $result -> free_result();
  echo "</tr>";
}

$connection -> close();


?>
</form>
                </tbody>
            </table>
			<center>
<h3><a href="../#book-a-table" target="_blank" style="text-decoration: none; color: #93e095;">Add New User</a></h3>
</center>
        </div>
    </div>
</div>
</div>
<!-- php -->
<?php
if ($_GET['page'] and $_GET['page']!='home'){
	$page =  ucfirst($_GET['page']);
	if ($page=='Users'){
		echo '<script>document.getElementById("users").style.display = "block";</script>';
	}
}
?>
</body>
</html>

