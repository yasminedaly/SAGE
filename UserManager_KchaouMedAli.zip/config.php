<?php

$servername="localhost";
$username="root";
$password="12312312";
$dbname="personnes";

?>